package com.example.mutualfunds.dao;

import com.example.mutualfunds.model.Fund;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FundDAO {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/mutualfunds_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "mohanaHM1130.";

    public List<Fund> getAllFunds() {
        List<Fund> funds = new ArrayList<>();
        String query = "SELECT * FROM funds";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Fund fund = new Fund(
                    rs.getString("fund_name"),
                    rs.getDouble("amount_invested"),
                    rs.getDouble("returns"),
                    rs.getString("investment_date")
                );
                funds.add(fund);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return funds;
    }
}
