package com.example.mutualfunds.model;

public class Fund {
    private String fundName;
    private double amountInvested;
    private double returns;
    private String investmentDate;

    public Fund(String fundName, double amountInvested, double returns, String investmentDate) {
        this.fundName = fundName;
        this.amountInvested = amountInvested;
        this.returns = returns;
        this.investmentDate = investmentDate;
    }

    public String getFundName() {
        return fundName;
    }

    public double getAmountInvested() {
        return amountInvested;
    }

    public double getReturns() {
        return returns;
    }

    public String getInvestmentDate() {
        return investmentDate;
    }
}
