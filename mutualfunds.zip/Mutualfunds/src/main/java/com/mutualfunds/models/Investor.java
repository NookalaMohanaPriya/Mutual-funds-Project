package com.mutualfunds.models;

public class Investor {
    private int id;
    private String name;
    private double portfolio;

    public Investor() {}

    public Investor(int id, String name, double portfolio) {
        this.id = id;
        this.name = name;
        this.portfolio = portfolio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPortfolio() {
        return portfolio;
    }

    public void setPortfolio(double portfolio) {
        this.portfolio = portfolio;
    }
}
