package com.mutualfunds.models;

public class MutualFund {
    private int id;
    private String name;
    private double amount;
    private double performance;

    public MutualFund() {}

    public MutualFund(int id, String name, double amount, double performance) {
        this.id = id;
        this.name = name;
        this.amount = amount;
        this.performance = performance;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getPerformance() {
        return performance;
    }

    public void setPerformance(double performance) {
        this.performance = performance;
    }
}
