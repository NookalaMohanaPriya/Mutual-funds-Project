package com.mutualfunds.model;

import java.math.BigDecimal;
import java.util.Date;

public class Investment {
    private int id;
    private String fundName;
    private BigDecimal amount;
    private Date dateInvested;

    // Getters and Setters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getFundName() {
        return fundName;
    }
    public void setFundName(String fundName) {
        this.fundName = fundName;
    }
    public BigDecimal getAmount() {
        return amount;
    }
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
    public Date getDateInvested() {
        return dateInvested;
    }
    public void setDateInvested(Date dateInvested) {
        this.dateInvested = dateInvested;
    }
}
