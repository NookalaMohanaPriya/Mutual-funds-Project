package com.mutualfunds.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.mutualfunds.model.Investment;

public class InvestmentDAO {
    private static final String URL = "jdbc:mysql://localhost:3306/mutualfunds";
    private static final String USER = "root";
    private static final String PASSWORD = "mohanaHM1130.";

    public List<Investment> getAllInvestments() {
        List<Investment> investments = new ArrayList<>();
        String query = "SELECT * FROM investments";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                Investment investment = new Investment();
                investment.setId(resultSet.getInt("id"));
                investment.setFundName(resultSet.getString("fund_name"));
                investment.setAmount(resultSet.getBigDecimal("amount"));
                investment.setDateInvested(resultSet.getDate("date_invested"));
                investments.add(investment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return investments;
    }
}
