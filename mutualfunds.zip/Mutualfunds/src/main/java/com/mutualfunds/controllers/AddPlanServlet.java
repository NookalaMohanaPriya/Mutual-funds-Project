package com.mutualfunds.controllers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

@WebServlet("/AddPlanServlet")
public class AddPlanServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the form parameters
        String planName = request.getParameter("planName");
        String planRiskLevel = request.getParameter("planRiskLevel");
        String returns = request.getParameter("returns");

        // Database connection settings
        String jdbcURL = "jdbc:mysql://localhost:3306/mutualfunds";
        String dbUser = "root";
        String dbPassword = "mohanaHM1130.";

        try {
            // Step 1: Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Step 2: Establish connection to the database
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            // Step 3: Create an SQL query
            String sql = "INSERT INTO investment_plans (plan_name, risk_level, expected_returns) VALUES (?, ?, ?)";

            // Step 4: Create a PreparedStatement
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, planName);
            statement.setString(2, planRiskLevel);
            statement.setString(3, returns);

            // Step 5: Execute the query
            int result = statement.executeUpdate();

            // Step 6: Close the connection
            statement.close();
            conn.close();

            // Step 7: Redirect to the investment plans page after successful addition
            response.sendRedirect("investmentPlans.jsp");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
