package com.mutualfunds.controllers;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/analyst")
public class DataAnalystServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Logic to handle analyst actions (e.g., analyze fund performance)
        request.getRequestDispatcher("/views/analyst.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Handle form submissions for analysis
        String fundId = request.getParameter("fundId");

        // Perform analysis using DAO (e.g., fetch fund performance)
        // DataAnalystDAO dao = new DataAnalystDAO();
        // String analysisResult = dao.analyzeFund(fundId);

        // Forward analysis results to the JSP page
        request.setAttribute("analysisResult", "Sample analysis result for fund " + fundId);
        request.getRequestDispatcher("/views/analyst.jsp").forward(request, response);
    }
}
