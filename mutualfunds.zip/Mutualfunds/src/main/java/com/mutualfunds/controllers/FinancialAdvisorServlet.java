package com.mutualfunds.controllers;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/advisor")
public class FinancialAdvisorServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Logic to handle advisor actions (e.g., provide advice, view funds)
        request.getRequestDispatcher("/views/advisor.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Handle form submissions like providing advice
        String fundId = request.getParameter("fundId");
        String advice = request.getParameter("advice");

        // Process the advice using the DAO (save advice or recommendations)
        // FinancialAdvisorDAO dao = new FinancialAdvisorDAO();
        // dao.giveAdvice(fundId, advice);

        // Redirect to a confirmation page or refresh the advisor dashboard
        response.sendRedirect("advisor");
    }
}
