package com.mutualfunds.controllers;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/investor")
public class InvestorServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Logic to handle investor actions (e.g., view investments, add investments)
        request.getRequestDispatcher("/views/investor.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Handle form submissions like adding investments
        String fundId = request.getParameter("fundId");
        double amount = Double.parseDouble(request.getParameter("amount"));

        // Process the investment using the DAO (Database Access Object)
        // MutualFundDAO dao = new MutualFundDAO();
        // dao.addInvestment(investorId, fundId, amount);

        // Redirect or forward to a confirmation page
        response.sendRedirect("investor");
    }
}
