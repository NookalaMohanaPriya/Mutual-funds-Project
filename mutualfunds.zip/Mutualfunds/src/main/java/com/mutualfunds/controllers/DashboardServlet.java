package com.mutualfunds.controllers;

import com.mutualfunds.dao.InvestmentDAO;
import com.mutualfunds.model.Investment;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        InvestmentDAO dao = new InvestmentDAO();
        List<Investment> investments = dao.getAllInvestments();
        request.setAttribute("investments", investments);
        request.getRequestDispatcher("dashboard.html").forward(request, response);
    }
}
