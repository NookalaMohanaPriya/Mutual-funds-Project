package org.json;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/getLatestInvestmentData")
public class GetLatestInvestmentDataServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String fundName = request.getParameter("fund");

        // Simulated response, in real case you should fetch this data from your database or financial APIs
        JSONObject jsonResponse = new JSONObject();
        if (fundName != null && fundName.equals("equityFundA")) {
            jsonResponse.put("values", new int[]{2000, 2200, 2150, 2350, 2300, 2450, 2400});
        } else {
            jsonResponse.put("values", new int[]{1000, 1100, 1150, 1200, 1250, 1300, 1350}); // Simulated data for other funds
        }

        // Set response headers
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(jsonResponse.toString());
    }
}
