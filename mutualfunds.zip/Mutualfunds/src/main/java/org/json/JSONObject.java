package org.json;

public class JSONObject {

	public void put(String string, int[] is) {
		// TODO Auto-generated method stub
		
	}

}
